export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyDtIl2mXyAEc-u8fTdoPnEfMgKxDdEMX7E",
    authDomain: "youconapp-155b2.firebaseapp.com",
    projectId: "youconapp-155b2",
    storageBucket: "youconapp-155b2.appspot.com", // Asegúrate que termine en .appspot.com
    messagingSenderId: "641705056447",
    appId: "1:641705056447:web:98fbc67c8fe0a26c2c8e0a",
    measurementId: "G-HEJPZ5JH08"
  }
};
